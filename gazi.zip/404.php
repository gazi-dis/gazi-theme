<?php 
	get_header();
?>
<!-- slider_area_start -->
    <div class="slider_area">
        <div class="single_slider  d-flex align-items-center bg-dark overlay">
            <div class="container">
                <div class="row align-items-center justify-content-start">
                    <div class="col-lg-12 col-md-12">
                        <div class="slider_text">
                            <h3 class="wow fadeInLeft" data-wow-duration="1s" data-wow-delay=".1s">
                                Aradığın sayfa bulunamadı
                            </h3>
                            <a class="boxed-btn2 wow fadeInLeft"  data-wow-duration="1s" data-wow-delay=".2s" href="<?php bloginfo('url'); ?>">Anasayfaya Git</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- slider_area_end -->
<?php 
	get_footer();
?>